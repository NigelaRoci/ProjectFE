document.addEventListener("DOMContentLoaded", function () {
    const userForm = document.getElementById("userForm");
    const userList = document.getElementById("userList");
    const searchInput = document.getElementById("search");

    // Load users from localStorage when the page loads
    const users = JSON.parse(localStorage.getItem("users")) || [];

    function saveUsersToLocalStorage() {
        localStorage.setItem("users", JSON.stringify(users));
    }

    function renderUser(user) {
        const userList = document.getElementById("userList");
        const li = document.createElement("li");
        li.classList.add("user-card");

        li.innerHTML = `
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/User-avatar.svg/2048px-User-avatar.svg.png" alt="Avatar">
        <div class="user-info">
            <span class="name">${user.name}</span>
            <span class="type">${user.type}</span>
        </div>
        <button class="delete-button">&#10006;</button>
    `;

        li.querySelector(".delete-button").addEventListener("click", () => {
            const index = users.indexOf(user);
            if (index !== -1) {
                users.splice(index, 1);
                li.remove();
                saveUsersToLocalStorage();
            }
        });

        userList.appendChild(li);
    }

    function filterUsers(searchText) {
        const filteredUsers = users.filter(user =>
            user.name.toLowerCase().includes(searchText.toLowerCase())
        );
        userList.innerHTML = "";
        filteredUsers.forEach(renderUser);
    }

    userForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const nameInput = document.getElementById("name");
        const typeSelect = document.getElementById("type");
        const name = nameInput.value.trim();
        const type = typeSelect.value;

        if (name.length < 2) {
            alert("Emri duhet te permbaje te pakten 2 karaktere");
            return;
        }

        const user = { name, type };
        users.push(user);
        renderUser(user);
        saveUsersToLocalStorage();

        nameInput.value = "";
        typeSelect.value = "Student";
    });

    searchInput.addEventListener("input", function () {
        filterUsers(searchInput.value);
    });

    users.forEach(renderUser);
}
);

